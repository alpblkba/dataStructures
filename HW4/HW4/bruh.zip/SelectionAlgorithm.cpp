#include <iostream>
#include <string>
#include <utility>
#include "SelectionAlgorithm.h"

using namespace std;


SelectionAlgorithm::SelectionAlgorithm(int k) {

	this->k = k;

}
